<?php

namespace App\Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Firebase\JWT\JWT;
use PDOException;
use Monolog\Logger;
use App\Helpers\ResponseHelper;

class AuthController
{
    private $db;
    private $logger;
    private $config;

    public function __construct(PDO $db, Logger $logger, array $config)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->config = $config;

    }

    public function login(Request $request, Response $response): Response
    {
        $params = $request->getParsedBody();
        $username = $params['username'] ?? '';
        $password = $params['password'] ?? '';

        $responseHelper = new ResponseHelper($response);
        
        $this->logger->info('Intento de inicio de sesión', [
            'username' => $request->getParsedBody()['username'] ?? 'unknown'
        ]);

        try {
            $stmt = $this->db->prepare("
                SELECT id, id_person, email, nombre, apellido, clave
                FROM inscripcion_alumnos.usuario
                WHERE cedula = :cedula AND active = 1
            ");

            $stmt->execute(['cedula' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // if ($user && password_verify($password, $user['clave'])) { // Si la contraseña tiene encriptado usar este condicionante
            if ($user && strcmp($password, $user['clave']) === 0) {
                $token = $this->generarToken($user['id'], $user['id_person']);

                $userData = [
                    'id' => $user['id'],
                    'id_person' => $user['id_person'],
                    'email' => $user['email'],
                    'nombre' => $user['nombre'],
                    'apellido' => $user['apellido']
                ];

                $result = [
                    'token' => $token,
                    'user' => $userData
                ];

                $this->logger->info('Inicio de sesión exitoso', [
                    'username' => $username,
                    'user_id' => $user['id']
                ]);

                return $responseHelper->respondWithJson($result, 200, 'Inicio de sesión exitoso');

            } else {
                $this->logger->warning('Inicio de sesión fallido', [
                    'username' => $username,
                    'reason' => 'Credenciales inválidas'
                ]);
                return $responseHelper->respondWithError('Credenciales inválidas o usuario inactivo', 401);
            }
        } catch (PDOException $e) {
            $this->logger->error('Error en la consulta de base de datos', ['error' => $e->getMessage()]);
            return $responseHelper->respondWithError('Error en el servidor', 500);
        }
    }

    public function register(Request $request, Response $response): Response
    {
        $data = $request->getParsedBody();
        $responseHelper = new ResponseHelper($response);

        // Validación básica de datos
        $requiredFields = ['doctype_id', 'cedula', 'nombre', 'apellidos', 'fechanac', 'tel_celular', 'email', 'clave'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                return $responseHelper->respondWithError("El campo $field es requerido", 400);
            }
        }

        $this->db->beginTransaction();

        try {
            // 1. Insertar en personas.persons
            $sqlPerson = "INSERT INTO personas.persons (nombre, apellidos, fechanac, estado_civil, email, tel_celular) 
                          VALUES (:nombre, :apellidos, :fechanac, 5, :email, :tel_celular) RETURNING id";
            $stmtPerson = $this->db->prepare($sqlPerson);
            $stmtPerson->execute([
                'nombre' => $data['nombre'],
                'apellidos' => $data['apellidos'],
                'fechanac' => $data['fechanac'],
                'email' => $data['email'],
                'tel_celular' => $data['tel_celular']
            ]);
            $personId = $stmtPerson->fetchColumn();

            // 2. Insertar en inscripcion_alumnos.usuario
            $sqlUsuario = "INSERT INTO inscripcion_alumnos.usuario 
                           (id_person, id_estado, id_rol, email, clave, cedula, nombre, apellido, fechanac, doctype_id, active, actualizar_datos, tel_celular) 
                           VALUES (:id_person, 3, 3, :email, :clave, :cedula, :nombre, :apellido, :fechanac, :doctype_id, 0, 0, :tel_celular)";
            $stmtUsuario = $this->db->prepare($sqlUsuario);
            $stmtUsuario->execute([
                'id_person' => $personId,
                'email' => $data['email'],
                'clave' => $data['clave'],
                'cedula' => $data['cedula'],
                'nombre' => $data['nombre'],
                'apellido' => $data['apellidos'],
                'fechanac' => $data['fechanac'],
                'doctype_id' => $data['doctype_id'],
                'tel_celular' => $data['tel_celular']
            ]);

            // 3. Insertar en personas.persons_docs
            $sqlPersonDocs = "INSERT INTO personas.persons_docs 
                              (doctype_id, person_id, valor, active, groupid) 
                              VALUES (:doctype_id, :person_id, :valor, 1, 1)";
            $stmtPersonDocs = $this->db->prepare($sqlPersonDocs);
            $stmtPersonDocs->execute([
                'doctype_id' => $data['doctype_id'],
                'person_id' => $personId,
                'valor' => $data['cedula']
            ]);

            $this->db->commit();
            $this->logger->info("Nuevo usuario registrado", ['email' => $data['email']]);

            return $responseHelper->respondWithJson(['id' => $personId], 201, 'Usuario registrado exitosamente');

        } catch (PDOException $e) {
            $this->db->rollBack();
            $this->logger->error("Error en el registro de usuario", ['error' => $e->getMessage()]);
            return $responseHelper->respondWithError('Error en el registro de usuario', 500);
        }
    }

    private function generarToken(string $userId, string $userIdPerson): string
    {
        $issuedAt = time();
        $expire = $issuedAt + 86400; // El token expira en 24 horas

        $payload = [
            'iat' => $issuedAt,
            'exp' => $expire,
            'userId' => $userId,
            'userIdPerson' => $userIdPerson
        ];

        return JWT::encode($payload, $this->config['jwt_secret'], 'HS256');
    }

}
