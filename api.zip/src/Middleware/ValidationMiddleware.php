<?php

namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Respect\Validation\Validator as v;
use Respect\Validation\Exceptions\NestedValidationException;

class ValidationMiddleware
{
    public function __invoke(Request $request, RequestHandler $handler)
    {
        $routeContext = RouteContext::fromRequest($request);
        $route = $routeContext->getRoute();

        // Si no hay ruta, simplemente pasamos la solicitud al siguiente middleware
        if (empty($route)) {
            return $handler->handle($request);
        }

        $routeName = $route->getName();
        $data = $request->getParsedBody() ?? [];

        try {
            $this->validateRoute($routeName, $data);
        } catch (NestedValidationException $exception) {
            $response = new \Slim\Psr7\Response();
            $response->getBody()->write(json_encode(['errors' => $exception->getMessages()]));
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(400);
        }

        return $handler->handle($request);
    }

    private function validateRoute($routeName, $data)
    {
        $rules = [
            'login' => [
                'username' => v::notEmpty()->stringType()->length(5, 255),
                'password' => v::notEmpty()->stringType()->length(5, 255),
            ],
            'register' => [
                'doctype_id' => v::notEmpty()->intVal(),
                'cedula' => v::notEmpty()->stringType()->length(5, 20),
                'nombre' => v::notEmpty()->stringType()->length(2, 50),
                'apellidos' => v::notEmpty()->stringType()->length(2, 50),
                'fechanac' => v::notEmpty()->date('Y-m-d'),
                'tel_celular' => v::notEmpty()->phone(),
                'email' => v::notEmpty()->email(),
                'clave' => v::notEmpty()->stringType()->length(6, 20)
            ],
            // Añadir más reglas para otras rutas según sea necesario
        ];

        if (!isset($rules[$routeName])) {
            return; // No hay reglas para esta ruta
        }

        $validator = v::keySet(
            v::key('username', $rules[$routeName]['username']),
            v::key('password', $rules[$routeName]['password'])
        );

        $validator->assert($data);
    }
}